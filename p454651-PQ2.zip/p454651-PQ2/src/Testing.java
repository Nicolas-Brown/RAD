import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Testing{

    @Test
    @DisplayName("Search test")
    public void searchInsert() throws Exception{
        BinaryTree.binarySearchTree tree = new BinaryTree.binarySearchTree();

        tree.insert("Drill");
        tree.insert("Hammer");
        tree.insert("Angle grinder");
        tree.insert("Saw");
        assertTrue(tree.search("hammer"));
    }

    @Test
    @DisplayName("Delete test")
    public void deleteInsert() throws Exception{
        BinaryTree.binarySearchTree tree = new BinaryTree.binarySearchTree();

        tree.insert("Drill");
        tree.insert("Hammer");
        tree.insert("Angle grinder");
        tree.insert("Saw");
        assertTrue(tree.search("hammer"));
        tree.deleteKey("Hammer");
        assertFalse(tree.search("hammer"));
    }

}
