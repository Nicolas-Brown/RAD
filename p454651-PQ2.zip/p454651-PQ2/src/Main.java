public class Main {
    public static void main(String[] args)  {
        BinaryTree.binarySearchTree tree = new BinaryTree.binarySearchTree();

        // insert into binary search tree
        tree.insert("Drill");
        tree.insert("Hammer");
        tree.insert("Angle grinder");
        tree.insert("Saw");
        tree.insert("Screwdriver");
        tree.insert("Clamp");
        tree.insert("Welder");
        tree.insert("Wrench");
        tree.insert("Router");
        tree.insert("Circular saw");
        tree.postOrder();

        System.out.println("Deleting Router from the tree");
        tree.deleteKey("Router");
        tree.postOrder();

        System.out.println("Searching for Clamp");
        tree.search("Clamp");

        System.out.println("Searching for Car");
        tree.search("Car");

    }
}

