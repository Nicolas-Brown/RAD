public class BinaryTree {
    static class binarySearchTree {
        //node class that defines BST node
        class Node {
            public String data;
            public Node left, right;

            public Node(String data) {
                this.data = data;
                left = right = null;
            }
        }

        // BST root node
        Node root;

        // Constructor for BST =>initial empty tree
        binarySearchTree() {
            root = null;
        }

        //delete a node from BST
        public void deleteKey(String data) {
            data = data.toLowerCase();
            root = deleteRecursive(root, data);
        }

        //recursive delete function
        public Node deleteRecursive(Node root, String data) {
            //tree is empty
            if (root == null) return root;

            //traverse left subtree
            if (data.compareTo(String.valueOf(root.data)) < 0)
                root.left = deleteRecursive(root.left, data);

                //traverse right subtree
            else if (data.compareTo(String.valueOf(root.data)) > 0)
                root.right = deleteRecursive(root.right, data);
            else {
                // node contains only one child
                if (root.left == null)
                    return root.right;
                else if (root.right == null)
                    return root.left;

                // node has two children;

                //get inorder successor
                root.data.equals(minValue(root.right));

                // Delete the inorder successor
                root.right = deleteRecursive(root.right, root.data);
            }
            return root;
        }

        public String minValue(Node root) {
            //initially minimum is root
            String min = root.data;
            //find minimum value
            while (root.left != null) {
                min = root.left.data;
                root = root.left;
            }
            return min;
        }

        // insert a node into binary tree
        public void insert(String data) {
            data = data.toLowerCase();
            root = insertRecursive(root, data);
        }

        //insert function
        public Node insertRecursive(Node root, String data) {
            //if tree is empty
            if (root == null) {
                root = new Node(data);
                return root;
            }
            //insert in the left subtree
            if (data.compareTo(String.valueOf(root.data)) < 0) {
                root.left = insertRecursive(root.left, data);
            }
            //insert in the right subtree
            else if (data.compareTo(String.valueOf(root.data)) > 0) {
                root.right = insertRecursive(root.right, data);
            }
            return root;
        }

        // method for traversing binary tree in order
        public void postOrder() {
            postOrderRecursive(root);
            System.out.println("\n");
        }

        public void postOrderRecursive(Node root) {
            if (root != null) {
                postOrderRecursive(root.left);
                System.out.print(root.data + ", ");
                postOrderRecursive(root.right);
            }
        }

        //search the binary tree for a node
        public boolean search(String data)  {
            data = data.toLowerCase();
            root = searchRecursive(root, data);
            if (root!= null) {
                System.out.println("item found: " + data);
                return true;
            }
            else {
                System.out.println("item not found: " + data);
                return false;
            }
        }

        //insert function
        public Node searchRecursive(Node root, String data)  {
            //root is null or data is present at root
            if (root==null || (data.compareTo(String.valueOf(root.data)) == 0)) {
                return root;
            }
            // value is greater than root data
            if (data.compareTo(String.valueOf(root.data)) < 0) {
                return searchRecursive(root.left, data);
            }
            // value is less than root data
            return searchRecursive(root.right, data);
        }
    }
}
