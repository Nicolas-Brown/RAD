<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-16">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>RAD Movie Search</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <!-- Color and font for all pages -->
  <link href="css/color.css" rel="stylesheet">

  <!-- Styles for the login pages -->
  <link href="css/loginPages.css" rel="stylesheet">

</head>

<body>


  <div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">RAD Movie Search</div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Main page</a>
      </div>
    </div>


    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="movies.php">Movies<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="searchgraph.php">Top 10 Searches<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="moviesSearch.php">Search<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="login.php">Login<span class="sr-only"></span></a>
            </li>
          </ul>
        </div>
      </nav>
        <!--Body Wrapper-->
        <div class="main_content">
            <br>
            <h1>Admin Controls</h1><br>

            <?php

            error_reporting(E_ALL);
            ini_set('display_errors', 1);
            
            session_start();

            //If admin has logged in
            if (isset($_SESSION['correctInfo']))
            {
              require "connect.php";

              echo "<h2>Users</h2><br>";

              //Get users from database
              $sql = "SELECT * FROM users";
              if ($result = mysqli_query($conn, $sql))
              {
                //If no users are found, display an error
                if (mysqli_num_rows($result) == 0)
                {
                  echo "No users in database.<br><br>";
                }
                
                //Users are found, display them in a table
                else
                {
                  //Table with headers
                  echo "<div style=\"overflow-x:auto\";><table align = left border = 1 class=\"center\">
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Email Status</th>
                      <th>Notification Status</th>
                    </tr>";

                  //Read user data into table
                  foreach ($result as $row)
                  {
                    echo "<tr>
                      <td>".$row['name'].
                      "</td><td>".$row['email'].
                      "</td><td>".$row['send_email'].
                      "</td><td>".$row['show_notification']."</td>
                      </tr>";
                  }
                  echo "</table><br>";
                }      
                mysqli_free_result($result);
              }  


              //Remove and unsubscribe buttons
              echo "<form method='get'><br><br><br><br><br><br>
                <p>Email:</p><input type='text' name='email' id='txtboxSize'><br><br>
                <button type='submit' name='remove' id='btnSize'>Remove</button>&nbsp
                <button type='submit' name='unsubscribe' id='btnSize'>Unsubscribe</button><br><br><br>
                </form>";
              
              //Remove button
              if (isset($_SESSION['removeEmail']))
              {
                //Query to remove user from database
                $email = ($_SESSION['removeEmail']);
                $sql = "DELETE FROM users WHERE email = '$email'";
                
                //If possible to run query
                if (mysqli_query($conn, $sql) === true && mysqli_affected_rows($conn) > 0)
                {  
                }
                //Otherwise, display an error
                else
                {
                  echo "<o>Email not found.</o><br><br>";
                }

                //Remove the session var
                unset($_SESSION['removeEmail']);
              }

              if (isset($_GET["remove"]))
              {
                //Set the session variable to remove user
                $_SESSION["removeEmail"] = ($_GET['email']);
                //Reload the page
                header("Location: adminControls.php");
              }
              
              //Unsubscribe button
              if (isset($_SESSION["unsubscribeEmail"]))
              {
                //Query to unsubscribe email in database
                $email = $_SESSION["unsubscribeEmail"];
                $sql = "UPDATE users SET send_email = 0, show_notification = 0 WHERE email = '$email'";
                
                //If possible to unsubscribe user
                if (mysqli_query($conn, $sql) === true && mysqli_affected_rows($conn) > 0)
                {
                }
                //Otherwise, display an error
                else
                {
                  echo "<o>Email not found or user is unsubscribed.</o><br><br>";
                }
                //Remove the session var
                unset($_SESSION['unsubscribeEmail']);
              }

              if (isset($_GET["unsubscribe"]))
              {
                //Set the session variable to remove user
                $_SESSION["unsubscribeEmail"] = ($_GET['email']);
                //Reload the page
                header("Location: adminControls.php");
              }

              //Logout button
              echo "<form method='get'>
                <p><button type='submit' name='logout' id=\"btnSize\">Logout</button></p><br>
                </form>";
                
              if (isset($_GET["logout"]))
              {
                //Remove the session var
                unset($_SESSION['correctInfo']);
                //Go to the admin login page
                header("Location: loginAdmin.php");
              }
            }
            
            //Othwerise go back to admin login page
            else
            {
              header("Location: loginAdmin.php");
            }
            ?>
            <br><br>
        </div>

      <!-- /#wrapper -->

      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

      <!-- Menu Toggle Script -->
      <script>
        $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#wrapper").toggleClass("toggled");
        });
      </script>
</body>