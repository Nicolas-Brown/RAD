<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-16">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>RAD Movie Search</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <!-- Color and font for all pages -->
  <link href="css/color.css" rel="stylesheet">

  <!-- Styles for the login pages -->
  <link href="css/loginPages.css" rel="stylesheet">

</head>

<body>


  <div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">RAD Movie Search</div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Main page</a>
      </div>
    </div>


    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="movies.php">Movies<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="searchgraph.php">Top 10 Searches<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="moviesSearch.php">Search<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="login.php">Login<span class="sr-only"></span></a>
            </li>
          </ul>
        </div>
      </nav>
        <!--Body Wrapper-->
        <div class="main_content">
        <br>
        <h1>Admin Log-in</h1><br>

        <form method="post">
          <p>Username</p><input type="text" name="name" id="txtboxSize"><br><br>
          <p>Password</p><input type="password" name="password" id="txtboxSize"><br><br>
          <button type="submit" name="signup" id="btnSize">Sign Up</button>&nbsp;
          <button type="submit" name="login" id="btnSize">Log in</button><br>
        </form>

        <?php
        $button = $_POST['submit'];

        require "connect.php";

        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        session_start();

        if (isset($_SESSION["message"]))
        {
          echo $_SESSION["message"];
          unset($_SESSION["message"]);
        }

        //Automatically go to the control page if the admin is logged in
        if (isset($_SESSION["correctInfo"]))
        {
          header("Location: adminControls.php");
        }
        
        //Login button
        if (isset($_POST["login"]))
        {
          $inputName = ($_POST["name"]);
          $inputPassword = ($_POST["password"]);
          
          //Check if admin name is already in database
          $sql = "SELECT password FROM admins WHERE username = '$inputName'";
          $result = mysqli_query($conn, $sql);

          //If admin is found
          if (mysqli_num_rows($result) > 0)
          {
            $row = mysqli_fetch_array($result);

            //If password matches the input
            if ($inputPassword == $row["password"])
            {
              //Allow access to adminControl.php
              $_SESSION["correctInfo"] = "true";
              header("Location: adminControls.php");
            }

            //Otherwise display an error
            else
            {
              $_SESSION["message"] = "Incorrect password.";
              header("Location: loginAdmin.php");
            }
          }

          //If no matching user is found, display an error
          else
          {
            $_SESSION["message"] = "'$inputName' is not a user.";
            header("Location: loginAdmin.php");
          }     
        }

        //Signup button
        if(isset($_POST["signup"]))
        {
          $inputName = ($_POST["name"]);
          $inputPassword = ($_POST["password"]);

          //Regex for name
          $namePattern = "(^[^;]+$)";
          //Regex for password
          $passPattern = "(^(?=.*[0-9])(?=.*[A-Z])(?!.*[^a-zA-Z0-9@#$^+=])(.{8,})$)";

          //If name matches the regex
          if (preg_match($namePattern, $inputName)) 
          {
            //And if password matches the regex
            if (preg_match($passPattern, $inputPassword)) 
            { 
              //Check if name is already in database
              $sql = "SELECT username FROM admins WHERE username = '$inputName'";
              $result = mysqli_query($conn, $sql);

              //If user exists, display an error
              if (mysqli_num_rows($result) > 0) 
              {
                $_SESSION["message"] = "User already exists.";
                header("Location: loginAdmin.php");
              }

              //Otherwise, add admin account
              else
              {
                //Query to add the admin to the database
                $sql = "INSERT INTO admins (username, password) VALUES('$inputName','$inputPassword')";
                
                //Add the admin account
                mysqli_query($conn, $sql);
                $_SESSION["message"] = "Sign up successful!";
                header("Location: loginAdmin.php");
              }
            }

            //Password doesnt match regex, display an error
            else
            {
              $_SESSION["message"] = "Invalid password.";
              header("Location: loginAdmin.php");  
            }
          }

          //Name doesnt match regex, display an error
          else
          {
            $_SESSION["message"] = "Invalid username.";
            header("Location: loginAdmin.php");
          }
        }
        ?>
        <br><br>
    </div>

      <!-- /#wrapper -->

      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

      <!-- Menu Toggle Script -->
      <script>
        $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#wrapper").toggleClass("toggled");
        });
      </script>
</body>